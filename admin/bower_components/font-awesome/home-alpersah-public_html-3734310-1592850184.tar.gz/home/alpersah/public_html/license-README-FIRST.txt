

Template Name: Yellow Blog
Template URI: http://www.wpfreeware.com/yellow-blog/
Author: WpFreeware
Author URI: http://www.wpfreeware.com
Version: 1.0 
License: GPL 2.0 or Later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


////////////////////////////////////////////////////////////////////////

Wordpress version also available here: 
http://www.wpfreeware.com/yellow-blog/

//////////////////////////////////////////////////////////////////////




---------------------------------------------
Find more great resources @ WpFreeware.com
Sincerely,
The WpFreeware Team.
---------------------------------------------
http://www.wpfreeware.com
PS. Those terms might change as we update our license on our website, 
please be sure to check the latest license terms on our website to avoid any misuse of our resources.

Thank you!